// Initialize Firebase
var config = {
  apiKey: "AIzaSyDxElF7AUfRx5sNRJo60gm_vb-Igwu610g",
  authDomain: "no-sleepers.firebaseapp.com",
  databaseURL: "https://no-sleepers.firebaseio.com",
  projectId: "no-sleepers",
  storageBucket: "no-sleepers.appspot.com",
  messagingSenderId: "120171091520"
};
firebase.initializeApp(config);
var database = firebase.database();
